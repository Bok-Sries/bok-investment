function decodeEntity(value) {
  return value
    .replaceAll("&amp;", "&")
    .replaceAll("&lt;", "<")
    .replaceAll("&gt;", ">")
    .replaceAll("&quot;", '"')
    .replaceAll("&#39;", "'")
    .replaceAll("&apos;", "'");
}

function stripTags(value) {
  return decodeEntity(value.replace(/<[^>]*>/g, "").trim());
}

function readTag(item, tagName) {
  const match = item.match(new RegExp(`<${tagName}[^>]*>([\\s\\S]*?)<\\/${tagName}>`, "i"));
  return match ? stripTags(match[1]) : "";
}

function parseRssItems(xml) {
  return [...xml.matchAll(/<item\b[\s\S]*?<\/item>/gi)].slice(0, 8).map(([item]) => {
    const source = item.match(/<source[^>]*>([\s\S]*?)<\/source>/i);
    const published = readTag(item, "pubDate");
    return {
      title: readTag(item, "title"),
      link: readTag(item, "link"),
      source: source ? stripTags(source[1]) : "",
      publishedAt: published ? new Date(published).toLocaleDateString("ko-KR", { month: "2-digit", day: "2-digit" }) : "",
    };
  });
}

export default async function handler(req, res) {
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  const symbol = (url.searchParams.get("symbol") || "").trim();
  const name = (url.searchParams.get("name") || symbol).trim();
  const isDomestic = /\.K[QS]$/i.test(symbol);
  const query = isDomestic ? `${name} 주식` : `${name} stock`;
  const rssUrl = `https://news.google.com/rss/search?q=${encodeURIComponent(query)}&hl=ko&gl=KR&ceid=KR:ko`;

  res.setHeader("Cache-Control", "s-maxage=300, stale-while-revalidate=600");

  try {
    const response = await fetch(rssUrl, {
      headers: { "User-Agent": "Mozilla/5.0 BOK-Invest-Dashboard/1.0" },
      signal: AbortSignal.timeout(7000),
    });
    if (!response.ok) throw new Error(`Google News returned ${response.status}`);
    const xml = await response.text();
    const articles = parseRssItems(xml).filter((article) => article.title && article.link);
    res.status(200).json({ symbol, name, articles });
  } catch (error) {
    res.status(200).json({ symbol, name, articles: [] });
  }
}
