const QUOTES = {
  KOSPI: ["KOSPI:KRX"],
  KOSDAQ: ["KQ11:KOSDAQ", "KOSDAQ:KOSDAQ", "KQ11:KRX"],
  NASDAQ: [".IXIC:INDEXNASDAQ"],
  SP500: [".INX:INDEXSP"],
  DOW: [".DJI:INDEXDJX"],
};

const NAVER_INDICES = {
  KOSPI: "KOSPI",
  KOSDAQ: "KOSDAQ",
};

function decodeHtml(value) {
  return value
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&nbsp;/g, " ");
}

function normalizeText(html) {
  return decodeHtml(
    html
      .replace(/<script[\s\S]*?<\/script>/gi, " ")
      .replace(/<style[\s\S]*?<\/style>/gi, " ")
      .replace(/<[^>]+>/g, "\n")
      .replace(/\s+/g, " "),
  );
}

function toNumber(value) {
  if (!value) return null;
  const parsed = Number(String(value).replace(/[,+%₩$]/g, "").trim());
  return Number.isFinite(parsed) ? parsed : null;
}

function parseGoogleFinance(html, quote) {
  const text = normalizeText(html);
  if (/Page Not Found|couldn't find any match/i.test(text)) return null;

  const escapedQuote = quote.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const quoteSection =
    html.match(new RegExp(`<div class="JV7gl">${escapedQuote}</div>[\\s\\S]{0,5000}`))?.[0] ||
    html.match(new RegExp(`${escapedQuote}[\\s\\S]{0,5000}`))?.[0] ||
    "";

  const priceMatch =
    quoteSection.match(/jsname="Pdsbrc"[^>]*>\s*<span>([^<]+)<\/span>/) ||
    html.match(new RegExp(`<div class="JV7gl">${escapedQuote}</div>[\\s\\S]*?jsname="Pdsbrc"[^>]*>\\s*<span>([^<]+)<\\/span>`));
  const percentMatch =
    quoteSection.match(/jsname="vY9t3b"[^>]*>\s*<span[^>]*>([+-]?\d+(?:\.\d+)?)%<\/span>/) ||
    html.match(new RegExp(`<div class="JV7gl">${escapedQuote}</div>[\\s\\S]*?jsname="vY9t3b"[^>]*>\\s*<span[^>]*>([+-]?\\d+(?:\\.\\d+)?)%<\\/span>`));

  const price = toNumber(priceMatch?.[1]);
  const percent = toNumber(percentMatch?.[1]);
  if (price === null || percent === null) return null;

  return {
    value: price,
    change: percent / 100,
    quote,
  };
}

async function fetchQuote(quote) {
  const url = `https://www.google.com/finance/quote/${encodeURIComponent(quote)}?hl=en`;
  const response = await fetch(url, {
    headers: {
      "User-Agent":
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125 Safari/537.36",
      "Accept-Language": "en-US,en;q=0.9,ko;q=0.8",
    },
  });
  if (!response.ok) return null;
  return parseGoogleFinance(await response.text(), quote);
}

async function fetchIndex(candidates) {
  for (const quote of candidates) {
    try {
      const parsed = await fetchQuote(quote);
      if (parsed) return parsed;
    } catch {
      // Try next candidate.
    }
  }
  return null;
}

async function fetchNaverIndex(code) {
  const url = `https://m.stock.naver.com/api/index/${code}/price?pageSize=2&page=1`;
  const response = await fetch(url, {
    headers: {
      "User-Agent":
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125 Safari/537.36",
      Referer: "https://m.stock.naver.com/",
      Accept: "application/json,text/plain,*/*",
    },
  });
  if (!response.ok) return null;
  const rows = await response.json();
  const latest = rows?.[0];
  if (!latest) return null;
  const value = toNumber(latest.closePrice);
  const change = toNumber(latest.fluctuationsRatio);
  if (value === null || change === null) return null;
  return {
    value,
    change: change / 100,
    quote: code,
    source: "네이버 지연",
    tradedAt: latest.localTradedAt,
  };
}

export default async function handler(request, response) {
  response.setHeader("Cache-Control", "s-maxage=60, stale-while-revalidate=300");
  response.setHeader("Access-Control-Allow-Origin", "*");

  const naverEntries = await Promise.all(
    Object.entries(NAVER_INDICES).map(async ([key, code]) => {
      try {
        return [key, await fetchNaverIndex(code)];
      } catch {
        return [key, null];
      }
    }),
  );

  const googleEntries = await Promise.all(
    Object.entries(QUOTES).map(async ([key, candidates]) => [key, await fetchIndex(candidates)]),
  );

  const mergedEntries = googleEntries.map(([key, googleValue]) => {
    const naverValue = naverEntries.find(([naverKey]) => naverKey === key)?.[1];
    return [key, naverValue || googleValue];
  });

  const indices = Object.fromEntries(
    mergedEntries
      .filter(([, value]) => value)
      .map(([key, value]) => [
        key,
        {
          ...value,
          source: value.source || "Google Finance 지연",
          fetchedAt: new Date().toISOString(),
        },
      ]),
  );

  response.status(200).json({ indices });
}
