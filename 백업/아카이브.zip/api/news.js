function decodeEntity(value) {
  return value
    .replaceAll("&amp;", "&")
    .replaceAll("&lt;", "<")
    .replaceAll("&gt;", ">")
    .replaceAll("&quot;", '"')
    .replaceAll("&#39;", "'")
    .replaceAll("&apos;", "'");
}

function stripTags(value) {
  return decodeEntity(value.replace(/<[^>]*>/g, "").trim());
}

function readTag(item, tagName) {
  const match = item.match(new RegExp(`<${tagName}[^>]*>([\\s\\S]*?)<\\/${tagName}>`, "i"));
  return match ? stripTags(match[1]) : "";
}

const impactSignals = [
  { words: ["실적", "영업이익", "매출", "순이익", "earnings", "revenue", "profit", "guidance"], label: "실적·가이던스", weight: 9 },
  { words: ["수주", "계약", "공급", "납품", "파트너십", "order", "contract", "supply", "partnership"], label: "수주·계약", weight: 8 },
  { words: ["시설투자", "신규 투자", "대규모 투자", "증설", "공장", "capex", "investment", "plant", "factory", "expansion"], label: "투자·증설", weight: 7 },
  { words: ["인수", "합병", "매각", "분할", "m&a", "acquisition", "merger", "spin-off", "sale"], label: "지배구조·M&A", weight: 8 },
  { words: ["목표가", "투자의견", "상향", "하향", "upgrade", "downgrade", "price target", "rating"], label: "증권사 의견", weight: 7 },
  { words: ["저평가", "고평가", "아직 싸다", "전망", "valuation", "undervalued", "overvalued", "outlook"], label: "밸류에이션 의견", weight: 6 },
  { words: ["규제", "제재", "조사", "소송", "특허", "recall", "regulation", "sanction", "probe", "lawsuit", "patent"], label: "규제·소송", weight: 8 },
  { words: ["노사", "파업", "성과급", "생산 차질", "공급 차질", "strike", "labor", "production halt"], label: "노무·운영 리스크", weight: 8 },
  { words: ["배당", "자사주", "주주환원", "dividend", "buyback"], label: "주주환원", weight: 6 },
  { words: ["정부", "정책", "보조금", "금리", "환율", "관세", "policy", "subsidy", "rate", "tariff"], label: "정책·거시", weight: 6 },
  { words: ["급등", "급락", "강세", "약세", "상승", "하락", "surge", "fall", "rally", "slump"], label: "가격 변동", weight: 5 },
];

const lowImpactTerms = [
  "연예",
  "스타",
  "장성규",
  "김구라",
  "실패담",
  "계좌 공개",
  "인증 화제",
  "개미의 세계",
  "초고수는 지금",
  "주식재산",
  "자산 인증",
  "celebrity",
  "portfolio reveal",
];

function getRecencyScore(publishedAtMs) {
  if (!Number.isFinite(publishedAtMs)) return 0;
  const ageHours = Math.max(0, (Date.now() - publishedAtMs) / 36e5);
  if (ageHours <= 24) return 5;
  if (ageHours <= 72) return 3;
  if (ageHours <= 168) return 1;
  return 0;
}

function scoreMarketImpact(article, name, symbol) {
  const haystack = `${article.title} ${article.source}`.toLowerCase();
  const matches = impactSignals
    .map((signal) => {
      const count = signal.words.reduce((sum, word) => sum + (haystack.includes(word.toLowerCase()) ? 1 : 0), 0);
      return count ? { ...signal, count } : null;
    })
    .filter(Boolean)
    .sort((a, b) => b.weight * b.count - a.weight * a.count);
  const nameHit = name && haystack.includes(name.toLowerCase()) ? 4 : 0;
  const symbolHit = symbol && haystack.includes(symbol.replace(/\..+$/, "").toLowerCase()) ? 2 : 0;
  const signalScore = matches.reduce((sum, item) => sum + item.weight * item.count, 0);
  const lowImpactPenalty = lowImpactTerms.some((term) => haystack.includes(term.toLowerCase())) ? 18 : 0;
  const impactScore = signalScore + nameHit + symbolHit + getRecencyScore(article.publishedAtMs) - lowImpactPenalty;
  const primary = matches[0];
  return {
    ...article,
    impactScore,
    impactLabel: primary ? primary.label : "종목 관련",
  };
}

function parseRssItems(xml) {
  return [...xml.matchAll(/<item\b[\s\S]*?<\/item>/gi)].slice(0, 24).map(([item]) => {
    const source = item.match(/<source[^>]*>([\s\S]*?)<\/source>/i);
    const published = readTag(item, "pubDate");
    const publishedAtMs = published ? Date.parse(published) : NaN;
    return {
      title: readTag(item, "title"),
      link: readTag(item, "link"),
      source: source ? stripTags(source[1]) : "",
      publishedAt: published ? new Date(published).toLocaleDateString("ko-KR", { month: "2-digit", day: "2-digit" }) : "",
      publishedAtMs,
    };
  });
}

export default async function handler(req, res) {
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  const symbol = (url.searchParams.get("symbol") || "").trim();
  const name = (url.searchParams.get("name") || symbol).trim();
  const isDomestic = /\.K[QS]$/i.test(symbol);
  const impactTerms = isDomestic
    ? "(실적 OR 수주 OR 투자 OR 목표가 OR 규제 OR 소송 OR 배당 OR 정책 OR 주가)"
    : "(earnings OR revenue OR guidance OR contract OR investment OR regulation OR lawsuit OR dividend OR \"price target\" OR stock)";
  const query = `${isDomestic ? `${name} 주식` : `${name} stock`} ${impactTerms}`;
  const rssUrl = `https://news.google.com/rss/search?q=${encodeURIComponent(query)}&hl=ko&gl=KR&ceid=KR:ko`;

  res.setHeader("Cache-Control", "s-maxage=300, stale-while-revalidate=600");

  try {
    const response = await fetch(rssUrl, {
      headers: { "User-Agent": "Mozilla/5.0 BOK-Invest-Dashboard/1.0" },
      signal: AbortSignal.timeout(7000),
    });
    if (!response.ok) throw new Error(`Google News returned ${response.status}`);
    const xml = await response.text();
    const articles = parseRssItems(xml)
      .filter((article) => article.title && article.link)
      .map((article) => scoreMarketImpact(article, name, symbol))
      .filter((article) => article.impactScore >= 10)
      .sort((a, b) => b.impactScore - a.impactScore || (b.publishedAtMs || 0) - (a.publishedAtMs || 0))
      .slice(0, 8)
      .map(({ publishedAtMs, ...article }) => article);
    res.status(200).json({ symbol, name, articles });
  } catch (error) {
    res.status(200).json({ symbol, name, articles: [] });
  }
}
